protocol Figurine : Toy{
      func isMoved()
}
