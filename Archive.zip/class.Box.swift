class Box: Packaging {
   var isOpen: Bool = false
   var toy: Toy? = nil
}
