// Step #1
var pony: Pony = Pony()

var goku: DragonBall = DragonBall(DBHeroes.KAMESENNIN)

pony.isMoved()
goku.isMoved()
