protocol Toy {
    var type: String { get }
    func isMoved()
}
